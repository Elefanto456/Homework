package forms;

import entities.ItsCompany;
import exceptions.CompanyException;
import repository.CompanyRepository;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormAddCompany extends JFrame {
    private JPanel mainPanel;
    private JTextField tfForName;
    private JLabel title;
    private JLabel forName;
    private JLabel forPhone;
    private JLabel forRank;
    private JTextField tfForPhone;
    private JTextField tfForRank;
    private JButton addButton;
    private JTextField tfForType;
    private JLabel forType;
    private JButton showButton;

    public FormAddCompany() {
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String addName = tfForName.getText();
                String addNumber = tfForPhone.getText();
                String addRank = tfForRank.getText();
                String addType = tfForType.getText();

                String message;
                message = "Регистрация прошла успешно";

                try {
                    ItsCompany company = new ItsCompany(addName, addNumber, addRank, addType);
                    CompanyRepository.addCompany(company);
                    JOptionPane.showMessageDialog(mainPanel, message);
                    tfForName.setText("");
                    tfForPhone.setText("");
                    tfForRank.setText("");
                    tfForType.setText("");

                } catch (CompanyException e1) {
                    message = e1.getMessage();
                    JOptionPane.showMessageDialog(mainPanel, message);
                    e1.printStackTrace();
                }
            }
        });
        showButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TableForm();
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("FormAddCompany");
        frame.setContentPane(new FormAddCompany().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
