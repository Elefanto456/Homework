package forms;

import entities.ItsCompany;
import repository.CompanyRepository;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class TableForm {
    private JFrame frame;
    private JPanel mainPanel;
    private JScrollPane scrollForTable;
    private JTable tableForCompany;
    private JLabel title;

    public TableForm() {
        frame = new JFrame();
        frame.setBounds(0, 0, 500, 500);

        frame.setLayout(new BorderLayout());
        mainPanel  = new JPanel(new GridBagLayout());

        title= new JLabel(" Communal Services And Amenities");


        String[] labels = {"Name", "Phone Number", "Rank", "Type"};
        ArrayList<ItsCompany> list = CompanyRepository.getAll();
        String[][] rows = CompanyRepository.getTable(list);

        tableForCompany = new JTable(rows, labels);
        tableForCompany.setEnabled(false);
        tableForCompany.setFillsViewportHeight(true);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        scrollForTable = new JScrollPane(tableForCompany);
        frame.add(scrollForTable, BorderLayout.NORTH);

        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(title, BorderLayout.NORTH);
        mainPanel.add(tableForCompany, BorderLayout.CENTER);

        frame.add(mainPanel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new TableForm();
    }
}
