package forms;

import entities.ItsCompany;
import repository.CompanyRepository;

import javax.swing.*;
import java.util.ArrayList;

public class FormForTable extends JFrame {

    private JPanel mainPanel;
    private JPanel panelForTitle;
    private JPanel panelForTable;
    private JLabel title;
    private JScrollPane scrollForTable;
    private JTable tableForCompany;

    public FormForTable() {
        String[] labels = {"Name", "Phone Number", "Rank", "Type"};
        ArrayList<ItsCompany> list = CompanyRepository.getAll();
        String[][] rows = CompanyRepository.getTable(list);
        tableForCompany = new JTable(rows, labels);
    }

    private void createUIComponents() {

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("FormForTable");
        frame.setContentPane(new FormForTable().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

}
