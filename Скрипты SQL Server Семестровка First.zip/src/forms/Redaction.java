package forms;

import entities.ItsCompany;
import exceptions.CompanyException;
import repository.CompanyRepository;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Redaction {

    private JFrame frame;
    private JPanel panel;
    private JLabel label;
    private JButton button;

    public Redaction(ItsCompany company) {
        frame = new JFrame();
        frame.setBounds(0,0,400,400);

        panel = new JPanel(new GridBagLayout());

        label = new JLabel("Redaction");

        button = new JButton();

        panel.add(label);
        final JLabel name= new JLabel("Name: ");
        final JLabel phoneNumber = new JLabel("phone: ");
        final JLabel rank = new JLabel("rank: ");
        final JLabel type = new JLabel("type: ");

        JTextField nameF = new JTextField(company.getName());
        JTextField phoneF = new JTextField(company.getPhoneNumber());
        JTextField rankF = new JTextField(company.getRankOfCompany());
        JTextField typeF = new JTextField(company.getTypeOfOwnership());

        panel.add(name);
        panel.add(nameF);
        panel.add(phoneNumber);
        panel.add(phoneF);
        panel.add(rank);
        panel.add(rankF);
        panel.add(type);
        panel.add(typeF);

        JButton button = new JButton("Red");
        ActionListener list = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nam = nameF.getText();
                String pho = phoneF.getText();
                String ran = rankF.getText();
                String typ = typeF.getText();

                String message;
                message = "Success";

                try {
                    ItsCompany company1 = new ItsCompany(nam, pho, ran, typ);

                    CompanyRepository.update(company1);
                    JOptionPane.showMessageDialog(panel, message);
                    nameF.setText("");
                    phoneF.setText("");
                    rankF.setText("");
                    typeF.setText("");

                } catch (CompanyException ex) {
                    message = ex.getMessage();
                    JOptionPane.showMessageDialog(panel, message);
                    ex.printStackTrace();
                }
            }
        };

        button.addActionListener(list);
        panel.add(button);
        frame.add(panel);

        frame.setVisible(true);

    }

}
