package repository;

import entities.ItsCompany;
import exceptions.CompanyException;
import utilities.DBService;

import java.sql.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CompanyRepository {

    public static void deleteById(int id) {
        String insert = "DELETE FROM Company WHERE id = ?";

        try {
            PreparedStatement p = DBService.connect().prepareStatement(insert);
            p.setInt(1, id);
            p.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addCompany(ItsCompany company) throws CompanyException {

        check(company);

        String insert = "INSERT INTO Company(name, phoneNumber, rankOfCompany, typeOfOwnership) VALUES (?,?,?,?)";
        Connection con = DBService.connect();

        try {
            CallableStatement st = con.prepareCall(insert);
            st.setString(1, company.getName());
            st.setString(2, company.getPhoneNumber());
            st.setString(3, company.getRankOfCompany());
            st.setString(4, company.getTypeOfOwnership());
            st.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static ItsCompany getById(int id) throws CompanyException {

        String insert = "SELECT name, phoneNumber, rankOfCompany, typeOfOwenship FROM Company WHERE id = ?";
        Connection con = DBService.connect();
        ItsCompany company = null;
        try {
            CallableStatement st = con.prepareCall(insert);
            st.setString(1, String.valueOf(id));
            ResultSet set = st.executeQuery();

            while (set.next()) {
                company = new ItsCompany (
                        id,
                        set.getString(1),
                        set.getString(2),
                        set.getString(3),
                        set.getString(4));
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return company;
    }

    private static void check(ItsCompany company) throws CompanyException {

        if (company == null) {
            throw new NullPointerException("Не бывает компаний без данных");
        }
        if (company.getName() == null || "".equals(company.getName())) {
            throw new CompanyException("Поле 'Название' не заполнено");
        }
        if (company.getPhoneNumber() == null || "".equals(company.getPhoneNumber())) {
            throw new CompanyException("Поле 'Номер телефона' не заполнено");
        }
        if (company.getRankOfCompany() == null || "".equals(company.getRankOfCompany())) {
            throw new CompanyException("Поле 'Ранг' не заполнено");
        }
        if (company.getTypeOfOwnership() == null || "".equals(company.getTypeOfOwnership())) {
            throw new CompanyException("Поле 'Форма собственности' не заполнено");
        }
    }

    public static ArrayList<ItsCompany> getAll() {
        ArrayList<ItsCompany> list = new ArrayList<>();
        Connection con = DBService.connect();
        String insert = "SELECT name, phoneNumber, rankOfCompany, typeOfOwnership FROM Company";
        try {
            PreparedStatement st = con.prepareStatement(insert);
            ResultSet set = st.executeQuery();
            while (set.next()) {
                list.add(new ItsCompany (
                        set.getString(1),
                        set.getString(2),
                        set.getString(3),
                        set.getString(4)));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static String[][] getTable(ArrayList<ItsCompany> list) {
        String[][] data = new String[list.size()][4];
        int i = 0;
        for (ItsCompany company : list) {
            data[i][0] = company.getName();
            data[i][1] = company.getPhoneNumber();
            data[i][2] = company.getRankOfCompany();
            data[i][3] = company.getTypeOfOwnership();
            i++;
        }
        return data;
    }

    public static void update(ItsCompany comp) throws CompanyException {
        check(comp);

        String insert = "UPDATE Company SET name = ?, phoneNumber = ?, rankOfCompany = ?, typeOfOwnership = ? WHERE id = ?";
        Connection con = DBService.connect();

        try {
            CallableStatement st = con.prepareCall(insert);
            st.setInt(4, comp.getId());
            st.setString(1, comp.getName());
            st.setString(2, comp.getPhoneNumber());
            st.setString(3, comp.getRankOfCompany());
            st.setString(4, comp.getTypeOfOwnership());
            st.execute();
        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    public static void intValidator(String age) throws CompanyException {
        final String PATTERN = "^[0-9][0-9]*$";
        Pattern pattern = Pattern.compile(PATTERN);
        Matcher matcher = pattern.matcher(age);
        if (!matcher.matches()) {
            throw new CompanyException("Поле заполнено некорректно или не заполнено. Используйте существующие числовые значения");
        }

    }

    public static void main(String[] args) {
        ArrayList<ItsCompany> list = getAll();
        list.forEach(System.out::println);
    }
}
