package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBService {

        private static Connection connection;
        //private static final String URI = "jdbc:sqlserver://localhost:49174;databaseName=Semestrovka2;integratedSecurity=true;";

        public static Connection connect() {
            try {
                Properties properties = new Properties();
                properties.load(new FileInputStream("C://Users/Acer/IdeaProjects/CommunalServicesAndAmenities/db.properties"));
                Class.forName(properties.getProperty("driver"));
                connection = DriverManager.getConnection(
                        properties.getProperty("url"),
                        properties.getProperty("user"),
                        properties.getProperty("password"));
            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Не удалось подключить драйвер БД");
            } catch (ClassNotFoundException e) {
                System.err.println("Драйвер не найден");
            } catch (IOException e) {
                e.printStackTrace();
            }
            return connection;
        }
    }