package utilities;

import entities.Company;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MyTableModel implements TableModel{
    private Set<TableModelListener> listeners = new HashSet<TableModelListener>();

    private List<Company> company;

    public MyTableModel(List<Company> company) {
        this.company = company;
    }

    public void addTableModelListener(TableModelListener listener) {
        listeners.add(listener);
    }

    public Class<?> getColumnClass(int columnIndex) {
        return String.class;
    }

    public int getColumnCount() {
        return 5;
    }

    public String getColumnName(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return "Name";
            case 1:
                return "Phone Number";
            case 2:
                return "Rank";
            case 3:
                return "Type Of Ownship";
            case 4:
                return "Address";
        }
        return "";
    }

    public int getRowCount() {
        return company.size();
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        Company oneCompany = company.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return oneCompany.getName();
            case 1:
                return oneCompany.getPhoneNumber();
            case 2:
                return oneCompany.getRang();
            case 3:
                return oneCompany.getTypeOfOwnership();
            case 4:
                return oneCompany.getAddressId();
        }
        return "";
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    public void removeTableModelListener(TableModelListener listener) {
        listeners.remove(listener);
    }

    public void setValueAt(Object value, int rowIndex, int columnIndex) {

    }
}
