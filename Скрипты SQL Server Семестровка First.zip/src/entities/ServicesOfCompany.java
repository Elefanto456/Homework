package entities;

import java.util.Map;

public class ServicesOfCompany {
    private int id;
    private String name;
    private Map<Company, UnitedCompanyServices> unitedCompanyServices;

    public ServicesOfCompany(int id, String name, Map<Company, UnitedCompanyServices> unitedCompanyServices) {
        this.id = id;
        this.name = name;
        this.unitedCompanyServices = unitedCompanyServices;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<Company, UnitedCompanyServices> getUnitedCompanyServices() {
        return unitedCompanyServices;
    }

    public void setUnitedCompanyServices(Map<Company, UnitedCompanyServices> unitedCompanyServices) {
        this.unitedCompanyServices = unitedCompanyServices;
    }
}
