package entities;

public class UnitedCompanySpecialization {
    private Company company;
    private Specialization specialization;

    public UnitedCompanySpecialization(Company company, Specialization specialization) {
        this.company = company;
        this.specialization = specialization;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Specialization getSpecialization() {
        return specialization;
    }

    public void setSpecialization(Specialization specialization) {
        this.specialization = specialization;
    }
}
