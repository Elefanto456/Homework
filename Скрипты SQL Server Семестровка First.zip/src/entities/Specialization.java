package entities;

import java.util.Map;

public class Specialization {
    private int id;
    private String name;
    private Map<Company, UnitedCompanySpecialization> UnitedCompanySpecialization;

    public Specialization(int id, String name, Map<Company, UnitedCompanySpecialization> unitedCompanySpecialization) {
        this.id = id;
        this.name = name;
        UnitedCompanySpecialization = unitedCompanySpecialization;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
