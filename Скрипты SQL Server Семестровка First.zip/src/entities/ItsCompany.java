package entities;

public class ItsCompany {
    private int id;
    private String name;
    private String phoneNumber;
    private String rankOfCompany;
    private String typeOfOwnership;
    ItsAddressOfCompany address;

    public ItsCompany() {
    }

    public ItsCompany(String name, String phoneNumber, String rankOfCompany, String typeOfOwnership) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.rankOfCompany = rankOfCompany;
        this.typeOfOwnership = typeOfOwnership;
    }

    public ItsCompany(int id, String name, String phoneNumber, String rankOfCompany, String typeOfOwnership){
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.rankOfCompany = rankOfCompany;
        this.typeOfOwnership = typeOfOwnership;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getRankOfCompany() {
        return rankOfCompany;
    }

    public void setRankOfCompany(String rankOfCompany) {
        this.rankOfCompany = rankOfCompany;
    }

    public String getTypeOfOwnership() {
        return typeOfOwnership;
    }

    public void setTypeOfOwnership(String typeOfOwnership) {
        this.typeOfOwnership = typeOfOwnership;
    }

    public ItsAddressOfCompany getAddress() {
        return address;
    }

    public void setAddress(ItsAddressOfCompany address) {
        this.address = address;
    }
}
