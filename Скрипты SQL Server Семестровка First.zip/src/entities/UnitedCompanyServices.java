package entities;

public class UnitedCompanyServices {
    private Company company;
    private ServicesOfCompany servicesOfCompany;

    public UnitedCompanyServices(Company company, ServicesOfCompany servicesOfCompany) {
        this.company = company;
        this.servicesOfCompany = servicesOfCompany;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public ServicesOfCompany getServicesOfCompany() {
        return servicesOfCompany;
    }

    public void setServicesOfCompany(ServicesOfCompany servicesOfCompany) {
        this.servicesOfCompany = servicesOfCompany;
    }
}
