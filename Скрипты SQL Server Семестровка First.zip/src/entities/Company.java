package entities;

import java.util.Map;

public class Company {
    private int id;
    private String name;
    private String phoneNumber;
    private String rang;
    private String typeOfOwnership;
    private String addressId;
    private Map<Specialization, UnitedCompanySpecialization> unitedCompanySpecialization;
    private Map<ServicesOfCompany, UnitedCompanyServices> unitedCompanyServices;
    private Map<Timetable, UnitedCompanyTimetable> unitedCompanyTimetable;

    public Company(String name, String phoneNumber, String rang, String typeOfOwnership, String addressId, Map<Specialization, UnitedCompanySpecialization> unitedCompanySpecialization, Map<ServicesOfCompany, UnitedCompanyServices> unitedCompanyServices, Map<Timetable, UnitedCompanyTimetable> unitedCompanyTimetable) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.rang = rang;
        this.typeOfOwnership = typeOfOwnership;
        this.addressId = addressId;
        this.unitedCompanyServices = unitedCompanyServices;
        this.unitedCompanySpecialization = unitedCompanySpecialization;
        this.unitedCompanyTimetable = unitedCompanyTimetable;
    }

    public Company(int id, String name, String phoneNumber, String rang, String typeOfOwnership, String addressId, Map<Specialization, UnitedCompanySpecialization> unitedCompanySpecialization, Map<ServicesOfCompany, UnitedCompanyServices> unitedCompanyServices, Map<Timetable, UnitedCompanyTimetable> unitedCompanyTimetable) {
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.rang = rang;
        this.typeOfOwnership = typeOfOwnership;
        this.addressId = addressId;
        this.unitedCompanyServices = unitedCompanyServices;
        this.unitedCompanySpecialization = unitedCompanySpecialization;
        this.unitedCompanyTimetable = unitedCompanyTimetable;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getRang() {
        return rang;
    }

    public void setRang(String rang) {
        this.rang = rang;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTypeOfOwnership() {
        return typeOfOwnership;
    }

    public void setTypeOfOwnership(String typeOfOwnership) {
        this.typeOfOwnership = typeOfOwnership;
    }

    public Map<Specialization, entities.UnitedCompanySpecialization> getUnitedCompanySpecialization() {
        return unitedCompanySpecialization;
    }

    public void setUnitedCompanySpecialization(Map<Specialization, entities.UnitedCompanySpecialization> unitedCompanySpecialization) {
        unitedCompanySpecialization = unitedCompanySpecialization;
    }

    public Map<ServicesOfCompany, UnitedCompanyServices> getUnitedCompanyServices() {
        return unitedCompanyServices;
    }

    public void setUnitedCompanyServices(Map<ServicesOfCompany, UnitedCompanyServices> unitedCompanyServices) {
        this.unitedCompanyServices = unitedCompanyServices;
    }

    public Map<Timetable, UnitedCompanyTimetable> getUnitedCompanyTimetable() {
        return unitedCompanyTimetable;
    }

    public void setUnitedCompanyTimetable(Map<Timetable, UnitedCompanyTimetable> unitedCompanyTimetable) {
        this.unitedCompanyTimetable = unitedCompanyTimetable;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }
}
