package entities;

import java.util.Map;

public class Timetable {
    private int id;
    private String weekday;
    private String openTime;
    private String closeTime;
    private Map<Company, UnitedCompanyTimetable> unitedCompanyTimetable;

    public Timetable(int id, String weekday, String openTime, String closeTime, Map<Company, UnitedCompanyTimetable> unitedCompanyTimetable) {
        this.id = id;
        this.weekday = weekday;
        this.openTime = openTime;
        this.closeTime = closeTime;
        this.unitedCompanyTimetable = unitedCompanyTimetable;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWeekday() {
        return weekday;
    }

    public void setWeekday(String weekday) {
        this.weekday = weekday;
    }

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }

    public String getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(String closeTims) {
        this.closeTime = closeTime;
    }

    public Map<Company, UnitedCompanyTimetable> getUnitedCompanyTimetable() {
        return unitedCompanyTimetable;
    }

    public void setUnitedCompanyTimetable(Map<Company, UnitedCompanyTimetable> unitedCompanyTimetable) {
        this.unitedCompanyTimetable = unitedCompanyTimetable;
    }
}
