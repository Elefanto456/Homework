package entities;

public class ItsAddressOfCompany {
    private int id;
    private String city;
    private String street;
    private String house;
    ItsCompany company;

    public ItsAddressOfCompany(){

    }

    public ItsAddressOfCompany(String city, String street, String house) {
        this.city = city;
        this.street = street;
        this.house = house;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }

    public ItsCompany getCompany() {
        return company;
    }

    public void ItsCompany (ItsCompany company) {
        this.company = company;
    }
}
