package entities;

public class UnitedCompanyTimetable {
    private Company company;
    private Timetable timetable;

    public UnitedCompanyTimetable(Company company, Timetable timetable) {
        this.company = company;
        this.timetable = timetable;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Timetable getTimetable() {
        return timetable;
    }

    public void setTimetable(Timetable timetable) {
        this.timetable = timetable;
    }
}
