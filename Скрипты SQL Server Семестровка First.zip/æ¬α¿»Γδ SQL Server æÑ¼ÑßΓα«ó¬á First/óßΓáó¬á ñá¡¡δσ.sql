USE Semestrovka2
GO

INSERT INTO ServicesOfCompany VALUES
	('replacement crane'),
	('check counters'),
	('replacement of sockets'),
	('the dismantling of the walls'),
	('disinfestation')

INSERT INTO Specialization VALUES
	('sanitary engineering'),
	('electrician services'),
	('building'),
	('destruction of insects')


INSERT INTO Timetable VALUES
	('Monday', '8:00:00', '20:00:00'),
	('Tuesday', '8:00:00', '20:00:00'),
	('Wednesday', '8:00:00', '20:00:00'),
	('Thursday', '8:00:00', '20:00:00'),
	('Friday', '8:00:00', '20:00:00'),
	('Saturday', '8:00:00', '20:00:00'),
	('Sunday', NULL, NULL)

INSERT INTO AddressOfCompany VALUES
	('Kazan', 'Kachalova', 82),
	('Kazan', 'Butlerova', 31),
	('Kazan', 'Dzerzhinsky', 9)

INSERT INTO Company(name, phoneNumber, rankOfCompany, typeOfOwnership, id_address) VALUES
	('CompanyFirst', '(085) 880-08-00', '1', 'state ownership', 1),
	('CompanySecond', '(085) 880-07-12', '2', 'individual ownership', 2),
	('CompanyThird', '(085) 880-05-65', '3', 'individual ownership', 3)

INSERT INTO UnitedCompanySpecialization VALUES
	(1, 1),
	(1, 2),
	(1, 3),
	(2, 1),
	(2, 2),
	(3, 3),
	(3, 4)

INSERT INTO UnitedCompanyServices VALUES
	(1, 1),
	(1, 2),
	(1, 3),
	(1, 4),
	(2, 1),
	(2, 2),
	(2, 3),
	(3, 4),
	(3, 5)