USE Semestrovka2
GO

UPDATE Company --��������
SET name = '��������'
WHERE id = 1


ALTER TABLE Company DROP CONSTRAINT FK_Company_ServicesOfCompanyID, FK_Company_SpecializationID, FK_Company_TimetablID
ALTER TABLE Company DROP COLUMN servicesOfCompanyID, specializationID, timetableID

ALTER TABLE Company ADD CONSTRAINT PK_Company_id PRIMARY KEY(id)
ALTER TABLE Company ADD CONSTRAINT FK_Company_Id FOREIGN KEY(id) REFERENCES AddressOfCompany(id)


DBCC CHECKIDENT (ServicesOfCompany , RESEED, 0) --����� �������� IDENTITY

DELETE FROM ServicesOfCompany 
WHERE id >= 1

SELECT * FROM ServicesOfCompany 
SELECT * FROM Specialization
SELECT * FROM Timetable
SELECT * FROM AddressOfCompany
SELECT * FROM Company
SELECT * FROM UnitedCompanyServices
SELECT * FROM UnitedCompanySpecialization
SELECT * FROM UnitedCompanyTimetable

DROP TABLE Specialization
DROP TABLE ServicesOfCompany 
DROP TABLE Timetable
DROP TABLE AddressOfCompany
DROP TABLE Company
DROP TABLE UnitedCompanyServices
DROP TABLE UnitedCompanySpecialization
DROP TABLE UnitedCompanyTimetable