USE Semestrovka2
GO

--DROP PROC GetNameOfCompanyWithSpecialization

CREATE PROC GetNameOfCompanyWithSpecialization
AS
SELECT c.name 
FROM Company AS c
WHERE EXISTS (
	SELECT idCompany FROM UnitedCompanySpecialization
	WHERE idSpecialization = '2' AND
	idCompany = c.id)

--EXEC GetNameOfCompanyWithSpecialization