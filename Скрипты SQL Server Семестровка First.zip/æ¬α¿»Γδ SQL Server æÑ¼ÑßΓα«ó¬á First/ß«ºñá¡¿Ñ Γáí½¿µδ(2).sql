CREATE DATABASE Semestrovka2
USE Semestrovka2
GO

CREATE TABLE Company (
	id int IDENTITY(1,1),
	name varchar(30),
	phoneNumber varchar(30) NOT NULL , 
	rankOfCompany int,
	typeOfOwnership varchar(30), --����� �������������
	id_address int,
	CONSTRAINT PK_Company_id PRIMARY KEY(id),
	CONSTRAINT UQ_Company_Name UNIQUE(name),
	CONSTRAINT CK_Company_phoneNumber CHECK (phoneNumber LIKE 
    ('([0-9][0-9][0-9]) [0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')), --������ �������: '(085) 880-08-00'
    CONSTRAINT FK_Company_Id FOREIGN KEY(id_address) REFERENCES AddressOfCompany(id_address)
)

CREATE TABLE ServicesOfCompany (
	id int IDENTITY(1,1),
	name varchar(30),
	CONSTRAINT PK_ServicesOfCompany_id PRIMARY KEY(id)
)

CREATE TABLE Specialization (
	id int IDENTITY(1,1),
	name varchar(30),
	CONSTRAINT PK_Specialization_id PRIMARY KEY(id)
)

CREATE TABLE Timetable (
	id int IDENTITY(1,1),
	weekday varchar(30),
	openTime time,
	closeTime time,
	CONSTRAINT PK_Timetable_id PRIMARY KEY(id)
)

CREATE TABLE AddressOfCompany (
	id_address int IDENTITY(1,1),
	city varchar(30),
	street varchar(30),
	house int,
	CONSTRAINT PK_AddressOfCompany_id PRIMARY KEY(id_address)
)

CREATE TABLE UnitedCompanySpecialization (
	id int IDENTITY(1,1),
	idCompany int,
	idSpecialization int,
	CONSTRAINT PK_UnitedCompanySpecializationID PRIMARY KEY(id),
	CONSTRAINT FK_UnitedCompanySpecialization_CompanyID FOREIGN KEY(idCompany) REFERENCES Company(id),
	CONSTRAINT FK_UnitedCompanySpecialization_SpecializationID FOREIGN KEY(idSpecialization) REFERENCES Specialization(id) ON UPDATE CASCADE
)

CREATE TABLE UnitedCompanyServices (
	id int IDENTITY(1,1),
	idCompany int,
	idServices int,
	CONSTRAINT PK_UnitedCompanyServicesID PRIMARY KEY(id),
	CONSTRAINT FK_UnitedCompanyServices_CompanyID FOREIGN KEY(idCompany) REFERENCES Company(id),
	CONSTRAINT FK_UnitedCompanyServices_ServicesID FOREIGN KEY(idServices) REFERENCES ServicesOfCompany(id) ON UPDATE CASCADE
)

CREATE TABLE UnitedCompanyTimetable (
	id int  IDENTITY(1,1),
	idCompany int,
	idTimetable int,
	CONSTRAINT PK_UnitedCompanyTimetableID PRIMARY KEY(id),
	CONSTRAINT FK_UnitedCompanyTimetable_CompanyID FOREIGN KEY(idCompany) REFERENCES Company(id),
	CONSTRAINT FK_UnitedCompanyTimetable_TimetableID FOREIGN KEY(idTimetable) REFERENCES Timetable(id)
)